﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Acme.Biz
{
    public class Coches
    {
        private string marca, modelo;

        /// <summary>
        /// Esta clase permite proporcionar el nombre de los corches y su marca
        /// </summary>
        /// <param name="marca">Contiene la marca a la que pertenece el coche</param>
        /// <param name="modelo">Contien el modelo del coche</param>
        public Coches(string marca, string modelo)
        {
            this.marca = marca;
            this.modelo = modelo;
        }

        public Coches() //Al decir sin parametros he supuesto que debía pedir los parametros, sino lo otro que se me ocurre es poner valores predeterminados en marca y modelo
        {
            marca = Console.ReadLine();
            modelo = Console.ReadLine();
        }

        public string CocheCompleto() { return marca + " " + modelo; }

        public string CocheFormal() { return "Aquí tiene su deseado " + modelo + " de la marca " + marca; }
    }
}
