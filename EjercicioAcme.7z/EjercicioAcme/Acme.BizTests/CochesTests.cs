﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Acme.Biz;
using System;
using System.Collections.Generic;
using System.Text;

namespace Acme.Biz.Tests
{
    [TestClass()]
    public class CochesTests
    {
        [TestMethod()]
        public void CochesTest() //En los constructores he hecho esto porque no sabía que se debe hacer para ellos en las pruebas unitarias
        {
            try
            {
                string a = "BMW", b = "No se de coches";

                Coches actual = new Coches(a, b);
            }
            catch(Exception) { Assert.Fail(); }
        }

        [TestMethod()]
        public void CochesTest1() //En este constructor no sabía como hacer para simular que le proporcionaba datos
        {
            try { Coches actual = new Coches(); }
            catch (Exception) { Assert.Fail(); }
        }

        [TestMethod()]
        public void CocheCompletoTest()
        {
            string a = "BMW", b = "No se de coches";
            string expected = "BMW No se de coches", actual;

            Coches target = new Coches(a, b);

            actual = target.CocheCompleto();
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void CocheFormalTest()
        {
            string a = "BMW", b = "No se de coches";
            string expected = "Aquí tiene su deseado No se de coches de la marca BMW", actual;

            Coches target = new Coches(a, b);

            actual = target.CocheFormal();
            Assert.AreEqual(expected, actual);
        }
    }
}