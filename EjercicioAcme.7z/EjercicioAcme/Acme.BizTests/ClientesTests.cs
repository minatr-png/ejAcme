﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Acme.Biz;
using System;
using System.Collections.Generic;
using System.Text;

namespace Acme.Biz.Tests
{
    [TestClass()]
    public class ClientesTests
    {
        [TestMethod()]
        public void NClienteAumentaTest()
        {
            Clientes juanjo = new Clientes();
            int expected = 1, actual;

            Clientes.NClienteAumenta();

            actual = juanjo.NCliente;

            Assert.AreEqual(expected, actual);
        }
    }
}