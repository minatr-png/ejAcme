﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Acme.Biz
{
    /// <summary>
    /// Esta clase controlaría cuantos clientes tiene la compañía.
    /// </summary>
    public class Clientes
    {
        private static int nCliente = 0;

        /// <summary>
        /// Este método permite devolver el valor que tiene nCliente
        /// </summary>
        public int NCliente { get { return nCliente; } }

        /// <summary>
        /// Este método aumenta el número de clientes
        /// </summary>
        public static void NClienteAumenta() { nCliente++; }
    }
}
