﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Acme.Biz;
using System;
using System.Collections.Generic;
using System.Text;

namespace Acme.Biz.Tests
{
    [TestClass()]
    public class ClientesTests
    {
        [TestMethod()]
        public void NClienteAumentaTest()
        {
            //Arrange
            Clientes juanjo = new Clientes();
            int expected = 1;

            Clientes.NClienteAumenta();

            //Act
            int actual = juanjo.NCliente;

            //Assert
            Assert.AreEqual(expected, actual);
        }
    }
}