﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Acme.Biz;
using System;
using System.Collections.Generic;
using System.Text;

namespace Acme.Biz.Tests
{
    [TestClass()]
    public class CochesTests
    {
        [TestMethod()]
        public void CocheCompletoTest()
        {
            //Arrange
            string a = "BMW", b = "No se de coches";
            string expected = "BMW No se de coches";

            Coches target = new Coches(a, b);

            //Act
            string actual = target.CocheCompleto();

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void CocheFormalTest()
        {
            //Arrange
            string a = "BMW", b = "No se de coches";
            string expected = "Aquí tiene su deseado No se de coches de la marca BMW";

            Coches target = new Coches(a, b);

            //Act
            string actual = target.CocheFormal();

            //Assert
            Assert.AreEqual(expected, actual);
        }
    }
}